# USE
- To change the input change "in.a"
- To check the output see "out.txt"
- To run use "make run"