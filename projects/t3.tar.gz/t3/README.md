# NOTES
I ran out of time on this challenge and so i did not end up having the parser generator dump itself to a source file. The parser generator will read the grammar and then use the generated SLR tables to run the grammar.

# USAGE
- make run