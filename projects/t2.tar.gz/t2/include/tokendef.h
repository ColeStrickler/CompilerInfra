#ifndef TOKENDEF_H
#define TOKENDEF_H


enum TOKENTYPE
{

};



#endif